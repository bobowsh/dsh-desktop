# DSH Kimi-compatible PPT

[English](README.md) | 中文

`dsh-kimi-ppt` 是可安装的 Kimi-compatible 演示文稿插件。它提供一条 PPT 路线，内置创作 Skill、本地 PPTD v2 工程工具、可编辑 PPTX 渲染、模板参考、审计记录和活动工作区交付。

## 输入框流程

标准输入框展示一个 `PPT` 按钮。选中后，服务端持久化 `presentationMode: ppt`，打开 Kimi 模板目录，并为当前会话激活内置 `kimi-ppt` Skill。Host 只注册以下模型工具：

- `pptd_list_files`、`pptd_read_file`、`pptd_write_file`、`pptd_add_asset`
- `pptd_import`、`pptd_render`
- `ppt_list_templates`、`ppt_get_template_reference`、`ppt_get_template_pages`

模板目录包含 22 套视觉参考包：21 套来自 `open-kimi-ppt-skill` 的 MIT 许可模板，7 个分类各保留 3 套；另包含用户提供的 58 页活力蓝逻辑图表模板。活力蓝模板在共享版式层统一移除右上角 logo，完整保留 58 页版式、页面图片和语义索引。模板选择以服务端状态为准，仅在 PPT 模式中进入模型上下文。

## 渲染与交付

模型在受限工作区内创作 PPTD 工程。详细 PPTD 模板参考会为每个文本区提供按区域几何计算的建议字符容量，Skill 按对应容量控制标题和正文长度。`pptd_render` 校验工程，渲染可编辑的 PowerPoint 原生对象，把源工程和 PPTX 写入新的可见工作区目录，并登记 Deck 和活动记录。既有输出目录保持不可变。

插件通过受限 Host 工具完成工程读写、导入和图片加入。工作区路径经过规范化和边界校验。密钥保留在沙箱外，插件不启动外部演示文稿引擎。

## 包内容

npm 产物包含 Host bundle、标准输入框客户端、CLI、Kimi Skill、PPTD 参考文档和模板页面图片。它不依赖 Kimi 在线服务，渲染能力由 `package.json` 声明的 JavaScript 依赖承接。

## 验证

在仓库根目录运行：

```bash
pnpm --filter dsh-kimi-ppt bundle
pnpm --filter @deepseek-ai/dsh-experimental-kimi-ppt-standard-adapter bundle
pnpm exec vitest run packages/experimental/office-ppt/tests/loader-composition.spec.ts packages/experimental/office-ppt-standard-adapter/tests/bundle.spec.ts packages/experimental/office-ppt-standard-adapter/tests/bundle.client.spec.ts
```

这些检查覆盖 Kimi-only RPC、工具集合、Skill 注册、适配器插槽和打包产物。原生 Office 视觉验收属于独立检查层。
