# Kimi-compatible PPT for DSH

English | [中文](README.zh.md)

`dsh-kimi-ppt` is an installable Kimi-compatible presentation plugin. It provides one PPT mode, a bundled authoring Skill, local PPTD v2 project tools, editable PPTX rendering, built-in template references, audit records, and active-workspace delivery.

## Composer flow

The standard Composer exposes one `PPT` action. Selecting it persists `presentationMode: ppt`, opens the Kimi template catalog, and activates the bundled `kimi-ppt` Skill for the session. The Host registers these model-facing tools:

- `pptd_list_files`, `pptd_read_file`, `pptd_write_file`, and `pptd_add_asset`
- `pptd_import` and `pptd_render`
- `ppt_list_templates`, `ppt_get_template_reference`, and `ppt_get_template_pages`

The template catalog contains 22 visual reference packs: 21 MIT-licensed packs derived from `open-kimi-ppt-skill` (three visually distinct templates in each of seven categories), plus the user-supplied 58-page Vitality Blue logic-chart pack. The Vitality Blue source is sanitized at the shared layout layer so every bundled page is logo-free, while its page geometry and semantic index remain intact. Template selection remains server-authoritative and enters model context only while PPT mode is active.

## Rendering and delivery

The model authors a workspace-confined PPTD project. Detailed PPTD template references include a geometry-derived recommended character capacity for every text region, and the Skill keeps authored copy within that value. `pptd_render` checks actual copy against its box geometry, typography, explicit line breaks, and wrapping mode. Overflow stops the render with the affected element and measured limit; accepted text retains its authored font size without automatic shrinking. The operation renders editable native PowerPoint objects, writes the source plane and PPTX into a new visible workspace directory, and records the resulting Deck and activity entry. Existing output folders remain immutable.

The package uses bounded Host tools for project reads, writes, imports, and image intake. Workspace paths are normalized and confined. Secrets stay outside the project, and the plugin starts no external presentation engine.

## Package contents

The npm artifact contains the Host bundle, standard Composer client, CLI, Kimi Skill, PPTD references, and template page images. It does not require a Kimi service. Its renderer is implemented with the packaged JavaScript dependencies declared in `package.json`.

## Verification

Run the focused build and composition gates from the repository root:

```bash
pnpm --filter dsh-kimi-ppt bundle
pnpm --filter @deepseek-ai/dsh-experimental-kimi-ppt-standard-adapter bundle
pnpm exec vitest run packages/experimental/office-ppt/tests/loader-composition.spec.ts packages/experimental/office-ppt-standard-adapter/tests/bundle.spec.ts packages/experimental/office-ppt-standard-adapter/tests/bundle.client.spec.ts
```

These gates verify the Kimi-only RPC route, tool surface, Skill registration, text-capacity enforcement, adapter slots, and bundled artifacts. Exact installed-font metrics and native Office rendering remain a separate acceptance step.
