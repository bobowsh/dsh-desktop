# PPTD visual composition reference

Use this reference to turn a content outline into a coherent deck before writing every page. The selected source template, user requirements, and factual evidence guide the composition.

## Choose the communication job

Classify the deck before authoring pages:

- **Editorial or photo-led:** one strong image, statement, or typographic gesture carries each page. Suitable for travel, brand, culture, product story, and consumer topics.
- **Analytical or data-led:** one chart, table, comparison, or evidence block carries each page. Suitable for research, operating reviews, and technical analysis.
- **Executive or decision-led:** one conclusion and its consequence carry each page. Suitable for management updates, proposals, and plans.
- **Minimal or statement-led:** a short statement, number, quotation, or transition carries the page. Use it deliberately between denser pages.

Do not mix these jobs without a deck-level reason. A source-backed template determines the visual language; this classification determines which of its page families fit the content.

## Define the page rhythm

For every page, decide five values before writing elements: page role, one-sentence claim, dominant visual, silhouette, and density. Keep this plan in the active reasoning; the PPTD project remains the source plane and does not need a planning file.

Use page roles such as cover, section, statement, evidence, comparison, process, gallery, summary, and closing. Each page has one dominant visual type: image, chart, table, diagram, large statement, or large number. Supporting objects explain that focus; they do not compete with it.

Build three to five reusable silhouettes for an ordinary deck. Adjacent pages should not repeat one silhouette more than twice unless the repeated structure is itself meaningful, such as a fixed KPI series or one-page-per-region appendix. Change the dominant visual position, scale, or grouping when the content job changes.

## Establish visual hierarchy

Use these ranges as starting points for a 960 × 540 canvas, then adapt to the selected template:

- Cover titles: 64–112 pt when typography is the primary visual.
- Content titles: 24–38 pt.
- Body copy: 12–18 pt.
- Captions and metadata: 9–12 pt.
- Outer margins: usually 36–60 pt, except intentional full-bleed media.

A cover needs one unmistakable focal point. Use a large image, chart, or table occupying at least one quarter of the canvas, or make the largest title at least three times the median visible text size. Content pages use one dominant visual region and a clear second reading level.

Use three to five theme colors with explicit roles. Keep one type family or a deliberate display/body pair. Remote font declarations are unsupported; choose an available family and inspect the rendered fallback.

## Establish the visual system

Before expanding the complete deck, author three representative pages:

1. The cover, which establishes typography, palette, margins, and image treatment.
2. The hardest content page, which proves the densest chart, table, comparison, or image composition.
3. A closing, section, or summary page, which proves the deck can change rhythm without changing visual language.

Use these representative pages to define the hierarchy, dominant visual, density, and text fit for the deck. Then apply the theme and reusable silhouettes to the remaining pages.

For a source-backed template, choose three representative source pages before this cycle and keep their `templateReference` mappings. For an imported PPTX, duplicate and refill the best existing page skeletons instead of rebuilding their coordinates.

## Fit content to the composition

Shorten or split content before shrinking text. Replace long prose with a conclusion plus evidence. Use native charts for comparisons and trends, native tables for lookup, and images for visual evidence. Decorative shapes establish alignment and emphasis; they do not substitute for a missing primary visual.

Use one strong image instead of several weak images. Match the displayed aspect ratio before adding an asset, use `cover` only when the crop preserves the subject, and keep the file extension consistent with the actual image bytes.

## Complete the deck

Write the pages in story order and convert the finished PPTD project directly with `pptd_render`. Keep first-read focus, adjacent silhouettes, image crops, title scale, text density, repeated headers and footers, and the transition between dense and sparse pages coherent during authoring.
