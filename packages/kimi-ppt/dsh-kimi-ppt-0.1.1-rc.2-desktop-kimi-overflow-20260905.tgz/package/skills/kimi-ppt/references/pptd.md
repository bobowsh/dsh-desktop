# Local PPTD v2 authoring reference

This contract defines the PPTD source schema accepted by the editable PPTX renderer. The model writes the current project and calls `pptd_render` directly; final PowerPoint or WPS open-edit-save acceptance remains a separate delivery gate.

## Project structure

```text
my-deck/
├── deck.pptd
├── pages/
│   ├── page-1.page
│   └── page-2.page
└── media/
    └── hero.png
```

Files are UTF-8 YAML. Paths use forward slashes and stay relative to the project root. HTTP and HTTPS resources are rejected. The project accepts at most 200 pages and 2,000 elements per page.

## Units and stacking

- `size`, `bounds`, `viewBox`, font sizes, line widths, offsets, and blur values use PowerPoint points.
- 72 points equal 1 inch.
- Widescreen 16:9 uses `size: [960, 540]`.
- Standard 4:3 uses `size: [720, 540]`.
- `bounds` is `[x, y, width, height]`.
- Elements render in array order. Later elements appear above earlier elements.
- Colors use `#RRGGBB` or `#RRGGBBAA`. Theme color references use `$name`.

## Manifest

```yaml
version: v2
title: Example deck
size: [960, 540]
template:
  id: source-template
  name: Source template
  sourceFile: source.pptx
  sourceSha256: 0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef
theme:
  colors:
    background: '#F6F8F7'
    surface: '#FFFFFF'
    text: '#102A2A'
    muted: '#5E7171'
    accent: '#159A8C'
    secondary: '#E96013'
  textStyles:
    title:
      fontFamily: Arial
      fontSize: 30
      bold: true
      color: $text
      lineHeight: 1.08
      align: [left, top]
    body:
      fontFamily: Arial
      fontSize: 15
      color: $text
      lineHeight: 1.2
      align: [left, top]
  tableStyles:
    evidence:
      cellStyle:
        fontFamily: Arial
        fontSize: 10
        color: $text
        fill: {type: solid, color: $surface}
        border: {color: '#D4DEDC', width: 0.6}
      firstRowStyle:
        bold: true
        fill: {type: solid, color: '#D9F2EE'}
pages:
  - pages/page-1.page
  - pages/page-2.page
```

Required manifest fields are `version`, `size`, and `pages`. Supported top-level fields are exactly `version`, `title`, `size`, `template`, `theme`, and `pages`.

## Page

```yaml
pageType: content
templateReference:
  sourceSlideNumber: 3
  rationale: The source evidence page already contains a title, native table, and conclusion band.
  contentRelationship: data
background: {type: solid, color: $background}
notes: Speaker notes stay editable.
elements: []
```

Supported page fields are exactly `pageType`, `templateReference`, `background`, `notes`, and `elements`. `templateReference.sourceSlideNumber` is a positive integer. `rationale` is a non-empty string. `contentRelationship` is one of `statement`, `independent`, `comparison`, `process`, `timeline`, `overlap`, `data`, or `generic`.

Every element requires a unique `elementId`, one supported `elementType`, and `bounds`. Common optional fields depend on the element type; unsupported fields fail rendering.

`template` and `templateReference` preserve template identity, content relationship, and page-level mapping evidence. They do not import or inherit a source master, layout, or slide object. Use `pptd_import` when a concrete PPTX must supply the editable page skeleton. A `visual-reference` source page can use editable preset/custom shapes to reproduce complex geometry.

## Text

```yaml
- elementId: page-title
  elementType: text
  bounds: [58, 42, 650, 58]
  content:
    text: 'The evidence points to one operating priority'
    style: $title
```

`content` accepts `text`, `style`, `fontFamily`, `fontSize`, `color`, `bold`, `italic`, `lineHeight`, `letterSpacing`, `wrap`, `textDirection`, and `align`. Explicit content fields override the referenced text style. `align` is `[horizontal, vertical]`; horizontal values are `left`, `center`, `right`, `justify`, and vertical values are `top`, `middle`, `bottom`.

The renderer estimates line use from the actual text, box geometry, font size, line height, letter spacing, bold weight, explicit line breaks, wrapping mode, and vertical direction. Text that exceeds the available lines or the width of a non-wrapping box fails `pptd_render` with the element ID and measured line or width limit. Increase the box, shorten the copy, or split the page; the renderer retains the authored font size instead of shrinking overflowing text.

Supported lightweight rich text includes HTML-like `b`, `strong`, `i`, `em`, `span style="color: ...; font-size: ...px"`, `br`, `p`, and `li`. Advanced underline, links, lists, superscript, subscript, gradient, and shadow semantics are normalized; use the supported lightweight fields when exact editable output matters.

Text elements may also use `rotation`, `opacity`, and `flip: [horizontal, vertical]`.

## Shape

```yaml
- elementId: accent-panel
  elementType: shape
  bounds: [58, 124, 286, 286]
  shapeName: roundRect
  fill: {type: solid, color: '#D9F2EE'}
  border: {color: $accent, width: 1}
```

Preset `shapeName` values follow PptxGenJS/PowerPoint preset names such as `rect`, `roundRect`, `ellipse`, `triangle`, `hexagon`, `chevron`, `arc`, `cloud`, and arrows. Unsupported preset names fail `pptd_render` with a format error.

A custom vector shape uses:

```yaml
- elementId: custom-wave
  elementType: shape
  bounds: [58, 420, 844, 32]
  shapeName: custom
  viewBox: [100, 20]
  path: 'M 0 12 C 20 2 40 18 60 8 C 75 0 88 14 100 4 L 100 20 L 0 20 Z'
  fill: {type: solid, color: $accent}
```

Custom shapes are vector fallback objects. Shapes may use `rotation`, `opacity`, `flip`, `fill`, `border`, and `shadow`. Gradient and image fills, shadows, and preset adjustments are normalized by the renderer.

## Line

```yaml
- elementId: process-arrow
  elementType: line
  bounds: [110, 250, 260, 20]
  viewBox: [260, 20]
  points: '0,10 260,10'
  border: {color: $accent, width: 2, style: solid}
  arrow: [null, triangle]
```

`points` contains at least two `x,y` pairs. Multi-point and smooth curves use vector fallback. Lines may use `rotation`, `opacity`, `flip`, `curve`, `arrow`, `border`, and `shadow`.

## Image

```yaml
- elementId: hero-image
  elementType: image
  bounds: [620, 0, 340, 270]
  src: media/hero.png
  fit: {mode: cover}
```

Supported local media are PNG, JPEG, GIF, WebP, and SVG, subject to project size limits. `fit.mode` is `fill`, `contain`, or `cover`. Images may use `rotation`, `opacity`, `flip`, `cropShape`, `crop`, `border`, and `shadow`. Ellipse crop is editable; custom crop shapes may rasterize. Crop, borders, and shadows are normalized by the renderer.

## Table

Column and row ratios must be non-negative and each list must sum to 1. The row matrix must fill the complete grid after spans are applied.

```yaml
- elementId: comparison-table
  elementType: table
  bounds: [58, 142, 844, 260]
  style: $evidence
  columnWidths: [0.28, 0.24, 0.24, 0.24]
  rowHeights: [0.22, 0.26, 0.26, 0.26]
  rows:
    - [{text: Dimension}, {text: Baseline}, {text: Current}, {text: Decision}]
    - [{text: Accuracy, bold: true}, {text: 72%}, {text: 86%, color: $accent}, {text: Scale}]
    - [{text: Cost, bold: true}, {text: High}, {text: Medium}, {text: Optimize}]
    - [{text: Risk, bold: true}, {text: High}, {text: Low}, {text: Proceed}]
```

Cells accept `text`, `rowSpan`, `colSpan`, `textStyle`, `fontFamily`, `fontSize`, `color`, `bold`, `italic`, `align`, `fill`, and `border`. `border` may be one border object, `null`, a two-item vertical/horizontal list, or a four-item top/right/bottom/left list.

## Chart

Native editable series types are `bar`, `line`, `area`, `scatter`, `bubble`, `pie`, and `radar`. A bar series becomes horizontal when `encode.x` is numeric and `encode.y` is categorical; otherwise it becomes a column chart. A pie series with `innerRadius` greater than zero becomes a doughnut chart.

```yaml
- elementId: trend-chart
  elementType: chart
  bounds: [58, 146, 844, 280]
  data:
    cols: [year, north, south]
    rows:
      - ['2022', 38, 31]
      - ['2023', 45, 35]
      - ['2024', 52, 40]
  series:
    - type: line
      name: North
      encode: {x: year, y: north}
      lineColor: $accent
      width: 2.5
      marker: {shape: circle, size: 5}
      dataLabels: {show: true, fontSize: 9, color: $text}
    - type: line
      name: South
      encode: {x: year, y: south}
      lineColor: $secondary
      width: 2.5
  xAxis:
    label: {fontSize: 9}
    gridLine: false
  yAxis:
    min: 0
    max: 60
    label: {fontSize: 9}
    gridLine: {color: '#DCE5E3', style: dot}
  legend: {show: true, position: bottom, fontSize: 9}
  fill: {type: solid, color: '#FFFFFF00'}
```

Each series needs a type and an `encode` map containing at least two column references. Pie and radar commonly use `category` and `value`; bubble also uses `size`. Series colors accept a color scalar such as `#2351EC` or `$accent`, or a solid paint such as `{type: solid, color: $accent}`. For example, a native bar or column series may use `fill: {type: solid, color: '#2351EC'}`. Pie `fill` also accepts an array of those values. Gradient and image paints are reserved for element fills and fail chart-series validation. Useful series fields include `name`, `fill`, `lineColor`, `areaColor`, `width`, `marker`, `dataLabels`, `innerRadius`, `stack`, `nullHandling`, `dataFilter`, and `yAxisIndex`.

Chart-level fields include `data`, `series`, `seriesDefaults`, `xAxis`, `yAxis`, `barWidth`, `barGap`, `categoryGap`, `spokeAxis`, `title`, `legend`, `dataLabels`, `fontFamily`, `fill`, `border`, and `shadow`.

`candlestick`, `waterfall`, `heatmap`, `treemap`, `sunburst`, and `sankey` currently fail local rendering as unsupported. Rebuild them from native tables, bars, shapes, and text.

## Icon

```yaml
- elementId: status-icon
  elementType: icon
  bounds: [58, 92, 20, 20]
  iconName: check
  color: $accent
```

Icons are normalized into editable text glyphs by the local renderer. For exact icons, use a local SVG image or custom vector shape.

## Paint and effects

```yaml
fill: {type: solid, color: '#159A8C'}
border: {color: '#159A8C', width: 1, style: dash}
shadow: {color: '#00000033', blur: 8, offset: [0, 3]}
```

Gradient fill:

```yaml
fill:
  type: gradient
  gradientType: linear
  angle: 0
  stops:
    - {position: 0, color: '#159A8C'}
    - {position: 1, color: '#0B5F57'}
```

The editable renderer preserves solid fills and borders natively. Gradient/image fills and shadows are normalized for some element types. Complex preset shapes, chart options, table themes, typography, crop, and effects may be normalized during PPTX conversion.

## Authoring rules

1. Reuse a small theme instead of repeating arbitrary colors and fonts.
2. Give every element a stable semantic ID.
3. Keep body text at or above 12 points for dense academic pages and 14–18 points for normal pages. Titles commonly use 26–38 points.
4. Leave consistent outer margins and align related objects to shared edges.
5. Keep charts and tables in the element list before labels that intentionally overlay them.
6. After all pages are written, call `pptd_render` with the project path and output file name.
