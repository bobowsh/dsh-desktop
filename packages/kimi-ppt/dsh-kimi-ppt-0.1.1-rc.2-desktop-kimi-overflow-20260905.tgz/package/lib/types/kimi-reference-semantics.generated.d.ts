/** Generated per-page Kimi raster semantics. Run scripts/generate-kimi-reference-semantics.mjs to refresh. */
export declare const KIMI_PPT_TEMPLATE_SEMANTICS: {
    readonly "moss-green-transformation": {
        readonly palette: {
            readonly background: "F3F3F3";
            readonly surface: "B7B7B7";
            readonly text: "125E42";
            readonly muted: "B7B7B7";
            readonly accent: "36AA7E";
            readonly secondary: "86C5AA";
        };
        readonly source: {
            readonly fileName: "moss-green-transformation-reference.jpg";
            readonly sha256: "e5e6d8815a23349fb8274cb4b83ab4337d619156cbbfd2e8399880cd190c76f7";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.38;
            readonly averageCharacters: 520;
            readonly visualGrammar: "editorial-forest";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Moss Green Transformation: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 2;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.43;
                readonly averageMediaFrames: 0.29;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 7 measured visual regions across 14 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0D442F";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "B7B7B7";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0D442F";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "B7B7B7";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0D442F";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "B7B7B7";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "B7B7B7";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 4 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-academic-curated-blue-line-courseware": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "D8DBE0";
            readonly text: "202124";
            readonly muted: "9AA0A6";
            readonly accent: "24C2E0";
            readonly secondary: "4285F4";
        };
        readonly source: {
            readonly fileName: "blue-line-courseware-reference.jpg";
            readonly sha256: "9637f2db0856bc8d58de9354531a8afc79549e6827fd77fc60ff99989f4305ed";
            readonly slideCount: 7;
            readonly averageTextBlocks: 2.43;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Blue Line Courseware: 7 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 2;
            }, {
                readonly family: "grid";
                readonly slideCount: 5;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 1.8;
                readonly averageMediaFrames: 0.2;
            }, {
                readonly family: "image-led";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [5];
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 1;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 6 measured visual regions across 13 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "D8DBE0";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "D8DBE0";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["evidence", "overview", "process"];
                readonly structureSummary: "Raster-indexed page 5: 6 measured visual regions across 15 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly backgroundFill: "D8DBE0";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "DBDCE1";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 3 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D8DBE0";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 7: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-academic-curated-pastel-derivation": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "FEF2E8";
            readonly text: "0064E0";
            readonly muted: "F1F4F7";
            readonly accent: "0064E0";
            readonly secondary: "0085FD";
        };
        readonly source: {
            readonly fileName: "pastel-derivation-reference.jpg";
            readonly sha256: "bf36968160c246b2903f7080d24e16b2324e51d92d80304b58a4c54d6b1851dd";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.5;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Pastel Derivation: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 1;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.29;
                readonly averageMediaFrames: 0.43;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 14 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FEF2E8";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 1 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "FEF2E8";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "FBEEDD";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly areaRatio: 0.5;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 2 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 3 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 6 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FEF2E8";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FBEEDC";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FEF2E8";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FBEDDC";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 3 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-academic-curated-wine-red-data": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "F3F3F3";
            readonly text: "000000";
            readonly muted: "A9AAAC";
            readonly accent: "00A2FF";
            readonly secondary: "820000";
        };
        readonly source: {
            readonly fileName: "wine-red-data-reference.jpg";
            readonly sha256: "2ee34bfca5b8db3ab91c5ac94e30716e491d1348d94f71e8db024eb4d90f08da";
            readonly slideCount: 7;
            readonly averageTextBlocks: 2.14;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Wine Red Data: 7 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 6;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 0.17;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 7 measured visual regions across 15 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "E8E8E8";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "A8A8A8";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "D9D9D9";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "A7A7A7";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "D7D7D7";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 3 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 3 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F3F3F3";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 7: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-business-curated-vitality-blue": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "F1F5FB";
            readonly text: "000000";
            readonly muted: "44546A";
            readonly accent: "0A47C2";
            readonly secondary: "0C55E7";
        };
        readonly source: {
            readonly fileName: "vitality-blue-reference.jpg";
            readonly sha256: "29729fab2132fc120eba39371e4093a51beefa099ac978965d92dc9965b3c68e";
            readonly slideCount: 58;
            readonly averageTextBlocks: 3.95;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Vitality Blue: 58 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 54;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 4.04;
                readonly averageMediaFrames: 1.48;
            }, {
                readonly family: "image-led";
                readonly slideCount: 3;
                readonly sampleSlideNumbers: readonly [11, 17, 42];
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 1.67;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 13 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0A55E7";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "5A5A5A";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly areaRatio: 0.5;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 5 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0B48C1";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 8 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 8 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "D5DCE4";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "3A90F7";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 5 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 4 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 7 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "030303";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 8: 9 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "282828";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 9;
                readonly sourceTitle: "Reference page 9";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 9: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 10;
                readonly sourceTitle: "Reference page 10";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 10: 9 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "010101";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "414141";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 11;
                readonly sourceTitle: "Reference page 11";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["evidence", "overview", "process"];
                readonly structureSummary: "Raster-indexed page 11: 6 measured visual regions across 16 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly areaRatio: 0.75;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 12;
                readonly sourceTitle: "Reference page 12";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 12: 8 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 13;
                readonly sourceTitle: "Reference page 13";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 13: 6 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 14;
                readonly sourceTitle: "Reference page 14";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 14: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0B56E7";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 15;
                readonly sourceTitle: "Reference page 15";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 15: 4 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "ABBBD2";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 16;
                readonly sourceTitle: "Reference page 16";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 16: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 17;
                readonly sourceTitle: "Reference page 17";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["evidence", "overview", "process"];
                readonly structureSummary: "Raster-indexed page 17: 8 measured visual regions across 16 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 540;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "000000";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 18;
                readonly sourceTitle: "Reference page 18";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 18: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly shape: "rect";
                    readonly fill: "1269ED";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "004BE6";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly areaRatio: 0.5;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 19;
                readonly sourceTitle: "Reference page 19";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 19: 8 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 20;
                readonly sourceTitle: "Reference page 20";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 20: 11 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B56E7";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "009EF5";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "434343";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0B64ED";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 21;
                readonly sourceTitle: "Reference page 21";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 21: 8 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "1269ED";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 22;
                readonly sourceTitle: "Reference page 22";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 22: 10 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0B56E7";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 23;
                readonly sourceTitle: "Reference page 23";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 23: 3 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 720;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 24;
                readonly sourceTitle: "Reference page 24";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 24: 12 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B49C1";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "010101";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 25;
                readonly sourceTitle: "Reference page 25";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 25: 6 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "010101";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 26;
                readonly sourceTitle: "Reference page 26";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 26: 7 measured visual regions across 11 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "1269ED";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 27;
                readonly sourceTitle: "Reference page 27";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 27: 7 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "404040";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "595959";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 28;
                readonly sourceTitle: "Reference page 28";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 28: 5 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 29;
                readonly sourceTitle: "Reference page 29";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 29: 6 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B58E7";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 30;
                readonly sourceTitle: "Reference page 30";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 30: 7 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B49C1";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 31;
                readonly sourceTitle: "Reference page 31";
                readonly family: "grid";
                readonly titlePosition: "right";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 31: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "1266EB";
                }, {
                    readonly kind: "title";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 32;
                readonly sourceTitle: "Reference page 32";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 32: 5 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "4999F7";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 33;
                readonly sourceTitle: "Reference page 33";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 33: 6 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 34;
                readonly sourceTitle: "Reference page 34";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 34: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "424243";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "424243";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 35;
                readonly sourceTitle: "Reference page 35";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 35: 6 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "1268ED";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 36;
                readonly sourceTitle: "Reference page 36";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 36: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B58E7";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 37;
                readonly sourceTitle: "Reference page 37";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 37: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 38;
                readonly sourceTitle: "Reference page 38";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 38: 10 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "D9D9DA";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B57E7";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 39;
                readonly sourceTitle: "Reference page 39";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 39: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 40;
                readonly sourceTitle: "Reference page 40";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 40: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "1268ED";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "3990F7";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "414141";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 41;
                readonly sourceTitle: "Reference page 41";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 41: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B56E7";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "DBE3EE";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 42;
                readonly sourceTitle: "Reference page 42";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["evidence", "overview", "process"];
                readonly structureSummary: "Raster-indexed page 42: 7 measured visual regions across 16 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "1268ED";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "003CBE";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "424242";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 43;
                readonly sourceTitle: "Reference page 43";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 43: 9 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "D9D9D9";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 44;
                readonly sourceTitle: "Reference page 44";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 44: 8 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B58E7";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 45;
                readonly sourceTitle: "Reference page 45";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 45: 5 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B56E7";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "3A90F7";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 46;
                readonly sourceTitle: "Reference page 46";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 46: 3 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "3A90F7";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 47;
                readonly sourceTitle: "Reference page 47";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 47: 8 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "146AED";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0B56E7";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 48;
                readonly sourceTitle: "Reference page 48";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 48: 10 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "146AED";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "414141";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "146AED";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 49;
                readonly sourceTitle: "Reference page 49";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 49: 10 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "C7D5EF";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "296BB7";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 50;
                readonly sourceTitle: "Reference page 50";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 50: 8 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly shape: "rect";
                    readonly fill: "0A48C1";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "3990F7";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 51;
                readonly sourceTitle: "Reference page 51";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 51: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "272727";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 52;
                readonly sourceTitle: "Reference page 52";
                readonly family: "grid";
                readonly titlePosition: "right";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 52: 7 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "020202";
                }, {
                    readonly kind: "title";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 53;
                readonly sourceTitle: "Reference page 53";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 53: 4 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "414141";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 54;
                readonly sourceTitle: "Reference page 54";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 54: 10 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "0C57E7";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "414141";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 55;
                readonly sourceTitle: "Reference page 55";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 55: 4 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "D8D9D9";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 56;
                readonly sourceTitle: "Reference page 56";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 56: 6 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 57;
                readonly sourceTitle: "Reference page 57";
                readonly family: "grid";
                readonly titlePosition: "right";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 57: 8 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "424242";
                }, {
                    readonly kind: "title";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 58;
                readonly sourceTitle: "Reference page 58";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 58: 8 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "F1F5FB";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "388BF3";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-business-indexed-ink-green-market-trends": {
        readonly palette: {
            readonly background: "000000";
            readonly surface: "080808";
            readonly text: "8A9492";
            readonly muted: "1A412E";
            readonly accent: "4BCC00";
            readonly secondary: "A6F05F";
        };
        readonly source: {
            readonly fileName: "ink-green-market-trends-reference.jpg";
            readonly sha256: "86c21a7d731367feabc150b60bd2d1098fcc06b43553d0b0b0fa0119745f42ff";
            readonly slideCount: 7;
            readonly averageTextBlocks: 2;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Ink Green Market Trends: 7 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 0;
                readonly averageMediaFrames: 1;
            }, {
                readonly family: "two-column";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [2];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly averageTextFrames: 1;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 5;
                readonly sampleSlideNumbers: readonly [3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.6;
                readonly averageMediaFrames: 0.2;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 2 measured visual regions across 16 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly shape: "rect";
                    readonly fill: "183E2D";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "080808";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly areaRatio: 1;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "two-column";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["comparison", "evidence", "overview"];
                readonly structureSummary: "Raster-indexed page 2: 1 measured visual regions across 7 occupied landmark cells; balanced density; two-column composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 4 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "1E2714";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 2 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 5 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 7: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly shape: "rect";
                    readonly fill: "183F2D";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "080808";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly areaRatio: 1;
                };
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-business-indexed-orange-tech": {
        readonly palette: {
            readonly background: "1D1D1D";
            readonly surface: "191919";
            readonly text: "111111";
            readonly muted: "191919";
            readonly accent: "FC7C3D";
            readonly secondary: "F16736";
        };
        readonly source: {
            readonly fileName: "orange-tech-reference.jpg";
            readonly sha256: "df3d061ed2d7201fcf17f3cea3da510cbc3b24ded6263baac2987d2e752176b3";
            readonly slideCount: 6;
            readonly averageTextBlocks: 2.67;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Orange Tech: 6 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 5;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.4;
                readonly averageMediaFrames: 0.4;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 11 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "782514";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 5 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FECEA9";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FC7C3C";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 7 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "191919";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 1 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 2 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "191919";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 6: 1 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-business-indexed-xuan-paper-annual": {
        readonly palette: {
            readonly background: "F2EFE6";
            readonly surface: "F5F2E9";
            readonly text: "111111";
            readonly muted: "83817D";
            readonly accent: "F6931C";
            readonly secondary: "52DA92";
        };
        readonly source: {
            readonly fileName: "xuan-paper-annual-reference.jpg";
            readonly sha256: "795065dde5e617fc31d3f4e2c19a18b2a662028150f264df034868f12b027d01";
            readonly slideCount: 8;
            readonly averageTextBlocks: 3.63;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Xuan Paper Annual: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 5;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "two-column";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [2];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 6;
                readonly sampleSlideNumbers: readonly [3, 4, 5, 6, 7, 8];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 3.5;
                readonly averageMediaFrames: 2;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 10 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "two-column";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["comparison", "evidence", "overview"];
                readonly structureSummary: "Raster-indexed page 2: 3 measured visual regions across 9 occupied landmark cells; balanced density; two-column composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 9 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "416AC5";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 11 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "342B56";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 6 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "53DA93";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 5 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "F5F2E9";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 2 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-consulting-curated-apricot-white-brief": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "D1D3D4";
            readonly text: "000000";
            readonly muted: "808285";
            readonly accent: "CC0000";
            readonly secondary: "231F20";
        };
        readonly source: {
            readonly fileName: "apricot-white-brief-reference.jpg";
            readonly sha256: "e5d7a9d584a7b44984b3e83373c46eb361856ed2cb29590bb967c6b8a516a9d1";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.5;
            readonly averageCharacters: 520;
            readonly visualGrammar: "editorial-forest";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Apricot White Brief: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.29;
                readonly averageMediaFrames: 0.29;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 4 measured visual regions across 14 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "989898";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 3 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D1D3D4";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 5 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D1D3D4";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-consulting-curated-indigo-due-diligence": {
        readonly palette: {
            readonly background: "E5E6E5";
            readonly surface: "FFFFFF";
            readonly text: "000000";
            readonly muted: "B2B3B2";
            readonly accent: "2151FF";
            readonly secondary: "00A9F4";
        };
        readonly source: {
            readonly fileName: "indigo-due-diligence-reference.jpg";
            readonly sha256: "9aeb6c0c17c88c06a222ecbf091052ad9be3a622a9de4762b47e4d919f97e09d";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.13;
            readonly averageCharacters: 520;
            readonly visualGrammar: "editorial-forest";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Indigo Due Diligence: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 6;
                readonly sampleSlideNumbers: readonly [2, 4, 5, 6, 7, 8];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 1.83;
                readonly averageMediaFrames: 0.17;
            }, {
                readonly family: "image-led";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [3];
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 3;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 3 measured visual regions across 8 occupied landmark cells; balanced density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "E6E6E6";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["evidence", "overview", "process"];
                readonly structureSummary: "Raster-indexed page 3: 7 measured visual regions across 16 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "FFFFFF";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 540;
                    readonly backgroundFill: "FFFFFF";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "041B2B";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "FFFFFF";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 540;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 540;
                    readonly backgroundFill: "FFFFFF";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 540;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-finance-curated-black-gold-ledger": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "F3F3F3";
            readonly text: "0A0A0A";
            readonly muted: "A7A7A7";
            readonly accent: "D6A000";
            readonly secondary: "A86038";
        };
        readonly source: {
            readonly fileName: "black-gold-ledger-reference.jpg";
            readonly sha256: "f8410fe6681d8b9b88e50ec598bb42f57ba5747121907c5eaf3c27d35b5b6d74";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.75;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Black Gold Ledger: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 5;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.43;
                readonly averageMediaFrames: 0.14;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 10 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "D6D6D6";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 3 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly backgroundFill: "F3F3F3";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-finance-curated-lake-blue-memo": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "EEF3F9";
            readonly text: "072535";
            readonly muted: "869198";
            readonly accent: "490E5A";
            readonly secondary: "0C989A";
        };
        readonly source: {
            readonly fileName: "lake-blue-memo-reference.jpg";
            readonly sha256: "316201850a3e6f1acc193a1ff865395b69c21e5bdbf3f5e2f6bd34afd0f56298";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.38;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Lake Blue Memo: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 6;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.33;
                readonly averageMediaFrames: 0.67;
            }, {
                readonly family: "image-led";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [8];
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 1;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 2 measured visual regions across 12 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "EEF3F9";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "EEF3F9";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "EEF3F9";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 1 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "EEF3F9";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 4 measured visual regions across 16 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly backgroundFill: "EEF3F9";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-finance-curated-prospect-annual": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "FBFFCC";
            readonly text: "000533";
            readonly muted: "998C00";
            readonly accent: "1EFF8F";
            readonly secondary: "A29AFF";
        };
        readonly source: {
            readonly fileName: "prospect-annual-reference.jpg";
            readonly sha256: "1420008a15360b1d1997b9bf771868c4c20f233a95edc7a70afcab30fdd8ec8c";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.75;
            readonly averageCharacters: 520;
            readonly visualGrammar: "blue-professional";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Prospect Annual: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.57;
                readonly averageMediaFrames: 0.14;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 4 measured visual regions across 15 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 6 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "A6FFD4";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly backgroundFill: "FBFFCC";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-promotion-curated-aqua-charity-report": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "FAF7F0";
            readonly text: "222520";
            readonly muted: "76A9DC";
            readonly accent: "FFC907";
            readonly secondary: "5493D3";
        };
        readonly source: {
            readonly fileName: "aqua-charity-report-reference.jpg";
            readonly sha256: "7b1c31c708b80b399d76792ffb1e88d47109c10a86745d0195557ae7c24cb516";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2;
            readonly averageCharacters: 520;
            readonly visualGrammar: "signal";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Aqua Charity Report: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 2;
            }, {
                readonly family: "grid";
                readonly slideCount: 6;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 8];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 1.67;
                readonly averageMediaFrames: 0.67;
            }, {
                readonly family: "image-led";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [7];
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 1;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 6 measured visual regions across 16 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly backgroundFill: "FAF7F0";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 540;
                    readonly shape: "rect";
                    readonly fill: "9AC3EB";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FFC906";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FAF7F0";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 1 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 4 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FAF7F0";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FFC906";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FAF7F0";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "FAF7F0";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "FAF7F0";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 1 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 1 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "image-led";
                readonly titlePosition: "left";
                readonly bodyColumns: 1;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["evidence", "overview", "process"];
                readonly structureSummary: "Raster-indexed page 7: 6 measured visual regions across 16 occupied landmark cells; dense density; image-led composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly backgroundFill: "FAF7F0";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 540;
                    readonly shape: "rect";
                    readonly fill: "FFC907";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 4 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-promotion-curated-cream-collage": {
        readonly palette: {
            readonly background: "F3E8D4";
            readonly surface: "D9F04A";
            readonly text: "171717";
            readonly muted: "E9A7B3";
            readonly accent: "F05A39";
            readonly secondary: "2657D7";
        };
        readonly source: {
            readonly fileName: "cream-collage-reference.jpg";
            readonly sha256: "99d9abc080e55e3693ee9a855fd234db7a058c34320625d48c74f87fecb95108";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.88;
            readonly averageCharacters: 520;
            readonly visualGrammar: "signal";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Cream Collage: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 5;
                readonly averageMediaFrames: 2;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.57;
                readonly averageMediaFrames: 1.43;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 8 measured visual regions across 13 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "2657D7";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly areaRatio: 0.375;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 12 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "2657D7";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "F05A39";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "F05A39";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "171717";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "181817";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "181717";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 3 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 5 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 3 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "D9F04A";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-promotion-indexed-gold-orange-type-journal": {
        readonly palette: {
            readonly background: "000000";
            readonly surface: "111113";
            readonly text: "E5E5E5";
            readonly muted: "886065";
            readonly accent: "FE9900";
            readonly secondary: "FFCB7F";
        };
        readonly source: {
            readonly fileName: "gold-orange-type-journal-reference.jpg";
            readonly sha256: "e891ec7eb5f6da628c5c91611016f9f566000981329305614ca4023683f67bd7";
            readonly slideCount: 8;
            readonly averageTextBlocks: 3.25;
            readonly averageCharacters: 520;
            readonly visualGrammar: "signal";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Gold Orange Type Journal: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "two-column";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [2];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 6;
                readonly sampleSlideNumbers: readonly [3, 4, 5, 6, 7, 8];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 3.33;
                readonly averageMediaFrames: 0;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly features: readonly ["statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 4 measured visual regions across 7 occupied landmark cells; balanced density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "two-column";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["comparison", "evidence", "overview"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 11 occupied landmark cells; dense density; two-column composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 3 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 2 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 5 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "FFFFFF";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 5 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "121214";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 3 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 4 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-strategy-indexed-dusk-violet-consulting": {
        readonly palette: {
            readonly background: "D6ECFE";
            readonly surface: "DCEFF8";
            readonly text: "111111";
            readonly muted: "8C95A4";
            readonly accent: "A100FF";
            readonly secondary: "8A00E6";
        };
        readonly source: {
            readonly fileName: "dusk-violet-consulting-reference.jpg";
            readonly sha256: "7761fe3ec792d10ea2bdddcb782f05b5435aa04cf45f716ed0b98e4e692da8f4";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.75;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Dusk Violet Consulting: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.86;
                readonly averageMediaFrames: 0.71;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 2 measured visual regions across 7 occupied landmark cells; balanced density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 3 measured visual regions across 10 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 3 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 9 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "DCEFF8";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 540;
                    readonly shape: "rect";
                    readonly fill: "07161D";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "DCEFF8";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "DCEFF8";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "06151C";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FEFEFE";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 540;
                    readonly areaRatio: 0.563;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 7 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "DCEFF8";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly shape: "rect";
                    readonly fill: "07161D";
                }, {
                    readonly kind: "title";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "DCEFF8";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FEFEFF";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly areaRatio: 0.5;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 5 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 1 measured visual regions across 11 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-strategy-indexed-map-strategy": {
        readonly palette: {
            readonly background: "F4F0E8";
            readonly surface: "9BD5D8";
            readonly text: "0B1F33";
            readonly muted: "5B6570";
            readonly accent: "2F5BFF";
            readonly secondary: "E4572E";
        };
        readonly source: {
            readonly fileName: "map-strategy-reference.jpg";
            readonly sha256: "00eab6833145d2d8e7d15ac941775d9ee18f482c6d3a374aac1d1c2477e84fd0";
            readonly slideCount: 6;
            readonly averageTextBlocks: 2.5;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Map Strategy: 6 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 1;
                readonly averageMediaFrames: 1;
            }, {
                readonly family: "grid";
                readonly slideCount: 5;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.8;
                readonly averageMediaFrames: 1;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 2 measured visual regions across 14 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "9BD5D8";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 3 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 1 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 4 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 1280;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "9BD5D8";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image", "kpi"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 6: 9 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "9BD5D8";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "9BD5D8";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "9BD5D8";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "9BD5D8";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-strategy-indexed-red-black-business": {
        readonly palette: {
            readonly background: "F6F6F6";
            readonly surface: "FFF1F1";
            readonly text: "070302";
            readonly muted: "454545";
            readonly accent: "FF4D4D";
            readonly secondary: "FF5454";
        };
        readonly source: {
            readonly fileName: "red-black-business-reference.jpg";
            readonly sha256: "11c4ae83a9b07100a2a3c2e0eba97db6d5a55d27ef1d6df990a210e5b907a2ba";
            readonly slideCount: 6;
            readonly averageTextBlocks: 2.83;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Red Black Business: 6 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly averageTextFrames: 4;
                readonly averageMediaFrames: 1;
            }, {
                readonly family: "grid";
                readonly slideCount: 5;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.6;
                readonly averageMediaFrames: 0.2;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "balanced";
                readonly features: readonly ["image", "statement", "kpi"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 9 occupied landmark cells; balanced density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FFF1F1";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FF4C4C";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 4 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 3 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "FF4C4C";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 4 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FFF1F1";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FF4B4B";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "C2C2C2";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 6: 5 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-work-curated-blue-flame-brand": {
        readonly palette: {
            readonly background: "06070B";
            readonly surface: "050A1E";
            readonly text: "F7F8FA";
            readonly muted: "6E757B";
            readonly accent: "1FB9D5";
            readonly secondary: "B8ECF9";
        };
        readonly source: {
            readonly fileName: "blue-flame-brand-reference.jpg";
            readonly sha256: "9ea5b2f03abbb9f8584468c2708a2e0bea4b0243ff00b91cfa2ac736787097df";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.75;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Blue Flame Brand: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 2;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.71;
                readonly averageMediaFrames: 0.43;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 5 measured visual regions across 13 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "050A1E";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly backgroundFill: "050A1E";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 5 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "050A1E";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "050A1E";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 1 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 7 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "1FB7D3";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 4 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "050A1E";
                }, {
                    readonly kind: "title";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 720;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 3 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-work-curated-moon-white-imagery": {
        readonly palette: {
            readonly background: "FFFFFF";
            readonly surface: "FDF8E0";
            readonly text: "99AAA0";
            readonly muted: "D6DDD9";
            readonly accent: "1ECF77";
            readonly secondary: "F3001C";
        };
        readonly source: {
            readonly fileName: "moon-white-imagery-reference.jpg";
            readonly sha256: "b0e3108684e7dea8326107457e4f6fcda485e26a84a1068e2dc8faecc2388baa";
            readonly slideCount: 8;
            readonly averageTextBlocks: 2.38;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Moon White Imagery: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 3;
                readonly averageMediaFrames: 1;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 2.29;
                readonly averageMediaFrames: 0;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["image", "statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 4 measured visual regions across 12 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "image";
                    readonly x: 320;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FDF8E0";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 180;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["kpi"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 6 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "7D9386";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 2 measured visual regions across 14 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 2 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 2 measured visual regions across 12 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 2 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 1 measured visual regions across 16 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
    readonly "kimi-work-indexed-color-stripes-documentary": {
        readonly palette: {
            readonly background: "FFF9F3";
            readonly surface: "FFFAF4";
            readonly text: "131323";
            readonly muted: "9E9E9F";
            readonly accent: "FFB901";
            readonly secondary: "6F2572";
        };
        readonly source: {
            readonly fileName: "color-stripes-documentary-reference.jpg";
            readonly sha256: "8e51800cf1b21bda56e1981181a2abf0c09cb2dbbf250badeba042b21afcb54f";
            readonly slideCount: 8;
            readonly averageTextBlocks: 1.75;
            readonly averageCharacters: 520;
            readonly visualGrammar: "orange-data";
            readonly recommendedDensity: "dense";
            readonly designSummary: "Color Stripes Documentary: 8 raster-indexed source pages with measured page regions, density, palette, and primary-visual scale.";
            readonly layoutPatterns: readonly [{
                readonly family: "cover";
                readonly slideCount: 1;
                readonly sampleSlideNumbers: readonly [1];
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly averageTextFrames: 2;
                readonly averageMediaFrames: 0;
            }, {
                readonly family: "grid";
                readonly slideCount: 7;
                readonly sampleSlideNumbers: readonly [2, 3, 4, 5, 6, 7];
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly averageTextFrames: 1.71;
                readonly averageMediaFrames: 0.43;
            }];
            readonly pageReferences: readonly [{
                readonly slideNumber: 1;
                readonly sourceTitle: "Reference page 1";
                readonly family: "cover";
                readonly titlePosition: "left";
                readonly bodyColumns: 2;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["cover", "section"];
                readonly structureSummary: "Raster-indexed page 1: 7 measured visual regions across 12 occupied landmark cells; dense density; cover composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "6F2572";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "C6B2E3";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FFB801";
                }, {
                    readonly kind: "text";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "6C7A61";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "C6B2E3";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 2;
                readonly sourceTitle: "Reference page 2";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 2: 4 measured visual regions across 11 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FFFAF4";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "6F2572";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 960;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 960;
                    readonly height: 180;
                    readonly areaRatio: 0.188;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 3;
                readonly sourceTitle: "Reference page 3";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 3: 4 measured visual regions across 13 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 320;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 360;
                    readonly textRole: "text";
                }, {
                    readonly kind: "image";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly backgroundFill: "FFFAF4";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "FFB901";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 4;
                readonly sourceTitle: "Reference page 4";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 4: 4 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "B8DCD2";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "B8DCD2";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 5;
                readonly sourceTitle: "Reference page 5";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 5: 4 measured visual regions across 15 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 540;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "B8DCD2";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly shape: "rect";
                    readonly fill: "B8DCD2";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 540;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly primaryVisual: {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 360;
                    readonly width: 640;
                    readonly height: 360;
                    readonly areaRatio: 0.25;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 6;
                readonly sourceTitle: "Reference page 6";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 6: 2 measured visual regions across 11 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 1280;
                    readonly height: 720;
                    readonly textRole: "title";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 180;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "C6B2E3";
                }];
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 7;
                readonly sourceTitle: "Reference page 7";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "dense";
                readonly features: readonly ["image"];
                readonly recommendedRoles: readonly ["matrix", "comparison", "evidence"];
                readonly structureSummary: "Raster-indexed page 7: 3 measured visual regions across 8 occupied landmark cells; dense density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly backgroundFill: "FFFAF4";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "162D27";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 1280;
                    readonly height: 180;
                    readonly textRole: "title";
                }];
                readonly primaryVisual: {
                    readonly kind: "image";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 640;
                    readonly height: 180;
                    readonly areaRatio: 0.125;
                };
                readonly jsxReference: "";
            }, {
                readonly slideNumber: 8;
                readonly sourceTitle: "Reference page 8";
                readonly family: "grid";
                readonly titlePosition: "left";
                readonly bodyColumns: 3;
                readonly density: "balanced";
                readonly features: readonly ["statement"];
                readonly recommendedRoles: readonly ["closing", "overview"];
                readonly structureSummary: "Raster-indexed page 8: 6 measured visual regions across 9 occupied landmark cells; balanced density; grid composition.";
                readonly zones: readonly [{
                    readonly kind: "shape";
                    readonly x: 0;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "6F2572";
                }, {
                    readonly kind: "shape";
                    readonly x: 320;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "162D27";
                }, {
                    readonly kind: "shape";
                    readonly x: 640;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "0777DE";
                }, {
                    readonly kind: "shape";
                    readonly x: 960;
                    readonly y: 0;
                    readonly width: 320;
                    readonly height: 180;
                    readonly shape: "rect";
                    readonly fill: "C6B2E4";
                }, {
                    readonly kind: "title";
                    readonly x: 0;
                    readonly y: 180;
                    readonly width: 960;
                    readonly height: 360;
                    readonly textRole: "title";
                }, {
                    readonly kind: "text";
                    readonly x: 0;
                    readonly y: 360;
                    readonly width: 320;
                    readonly height: 180;
                    readonly textRole: "text";
                }];
                readonly jsxReference: "";
            }];
            readonly extractedAt: "2026-08-27T00:00:00.000Z";
        };
    };
};
//# sourceMappingURL=kimi-reference-semantics.generated.d.ts.map