/** Trusted-browser RPC for the independent Kimi PPT composer. */
import type { ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection';
import { type KimiPptService } from './kimi-service.ts';
/** Create the state-only RPC used by the Kimi composer button and template browser. */
export declare function kimiPptRpc(service: KimiPptService): ConnectionRpcHandler;
//# sourceMappingURL=kimi-rpc.d.ts.map