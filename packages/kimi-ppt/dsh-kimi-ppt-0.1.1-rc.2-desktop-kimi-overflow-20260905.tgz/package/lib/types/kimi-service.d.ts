/** Application service for the independent Kimi-compatible PPTD route. */
import type { SessionId } from '@deepseek-ai/dsh-session/types';
import { type PptdProject } from './pptd.ts';
import { type OfficeDeck, type OfficePptState, type OfficeTemplate, type OfficeTemplatePageReference } from './protocol.ts';
import { KimiPptStore } from './kimi-store.ts';
/** Host-side limits for direct PPTD rendering. */
export interface KimiPptLimits {
    readonly maxSlides: number;
}
/** Attributed caller crossing the browser or model boundary. */
export interface KimiPptActor {
    readonly kind: 'user' | 'agent';
}
/** Error with a stable RPC-facing business category. */
export declare class KimiPptError extends Error {
    readonly code: 'invalid-request' | 'not-found' | 'conflict' | 'unsupported' | 'limit-exceeded' | 'operation-failed';
    constructor(code: 'invalid-request' | 'not-found' | 'conflict' | 'unsupported' | 'limit-exceeded' | 'operation-failed', message: string);
}
/** Complete local workflow for the Kimi composer, browser state, and model tools. */
export declare class KimiPptService {
    private readonly store;
    private readonly limits;
    private readonly locks;
    constructor(store: KimiPptStore, limits: KimiPptLimits);
    state(sessionId: SessionId): Promise<OfficePptState>;
    templatePages(sessionId: SessionId, templateId: string, slideNumbers?: readonly number[]): Promise<readonly OfficeTemplatePageReference[]>;
    selectTemplate(sessionId: SessionId, templateId: string, actor: KimiPptActor): Promise<OfficeTemplate>;
    selectPresentationMode(sessionId: SessionId, active: boolean, actor: KimiPptActor): Promise<boolean>;
    deselectTemplate(sessionId: SessionId, actor: KimiPptActor): Promise<boolean>;
    createPptdDeck(sessionId: SessionId, project: PptdProject, requestedFileName: string, workspaceRoot: string, actor: KimiPptActor, signal: AbortSignal): Promise<OfficeDeck>;
    private mutate;
    private activity;
    private withLock;
}
//# sourceMappingURL=kimi-service.d.ts.map